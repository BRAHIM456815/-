function selectLevel(page) {
  window.location.href = page;
}